package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Learner;
import com.cg.repository.LearnerRepository;

@Service
public class LearnerServiceImpl implements LearnerService {

	
	@Autowired//DI
	LearnerRepository learnerRepository;
	
	@Override
	public Learner saveLearner(Learner learner) {
		// TODO Auto-generated method stub
//		Learner learner1= learnerRepository.save(learner);
//		if(learner1!=null)
//			return true;
//		else 
//			return false;
	return learnerRepository.save(learner);
	
	}

	@Override
	public List<Learner> fetchLearnerList() {
		
		return learnerRepository.findAll();
	}

	@Override
	public Learner fetchLearner(int learnerId)
	{
		return learnerRepository.findById(learnerId).get();
	}
	
	@Override
	public Learner updateLearner(Learner learner, int learnerId) {
		// TODO Auto-generated method stub
		
		Learner learn=learnerRepository.findById(learnerId).get();
		if(learn!=null)
		{
			//if(learner.getLearnerName()!="")
			learn.setLearnerName(learner.getLearnerName());
			learn.setLearnerContact(learner.getLearnerContact());
		}
		learnerRepository.save(learn);
		
		return learn;
	}

	@Override
	public boolean deleteLearnerById(int learnerId) {
		// TODO Auto-generated method stub
		try
		{
		
			learnerRepository.deleteById(learnerId);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
		
	}

}
