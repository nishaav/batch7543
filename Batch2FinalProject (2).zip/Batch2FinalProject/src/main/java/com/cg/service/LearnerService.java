package com.cg.service;
import java.util.List;

import com.cg.entity.Learner;

public interface LearnerService {

	//save operation
	Learner saveLearner(Learner learner);
	
	//read operation
	List<Learner> fetchLearnerList();
	
	
	Learner fetchLearner(int learnerId);
	//update operation
	Learner updateLearner(Learner learner, int learnerId);
	
	//delete operation
	boolean deleteLearnerById(int learnerId);
	
	
}
