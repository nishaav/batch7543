package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="learner_details")
public class Learner {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int learnerId;
	
	@Column(nullable=false)
	private String learnerName;
	
	@Column(nullable=false)
	private String learnerContact;

	public int getLearnerId() {
		return learnerId;
	}

	public void setLearnerId(int learnerId) {
		this.learnerId = learnerId;
	}

	public String getLearnerName() {
		return learnerName;
	}

	public void setLearnerName(String learnerName) {
		this.learnerName = learnerName;
	}

	public String getLearnerContact() {
		return learnerContact;
	}

	public void setLearnerContact(String learnerContact) {
		this.learnerContact = learnerContact;
	}

	
	
}
