import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import Mukesh from './App';
// import Edu from './demo';
//import Op from './ApiCallingExample';
//import UnComp from './ComponentUnmountPhase';
// import UpComp from './UpdatingComponent';
//import Comp from './ReactClassComponent';
// import JS from './ClassDemo';
import reportWebVitals from './reportWebVitals';
import Batch from './App';
//import same from './SameandDifferent.png';
//var comp=require('./SameandDifferent.png');
//import <aliasname> from <filename>
import Dummy from './ClassDemo';
import MyComp from './ReactClassComponent';
import photo from './img.jpg';
import UnComp from './ComponentUnmountPhase';
import UpComp from './UpdatingComponent';
import FormEx from './Form';
ReactDOM.render(
  <React.StrictMode>
    <FormEx></FormEx>
  </React.StrictMode>,
  document.getElementById('root')
);

// ReactDOM.render(
//   <React.StrictMode>
//     <Batch name="EduBridge" path={photo}></Batch>
//   </React.StrictMode>,
//   document.getElementById('root')
// );
//render(whattorender,where to render)
//React JS is based upon ES6 which stands for Ecmascript 2015 that is a version of javascript 
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
/** 
 * 
 * const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Kiran name="edu" path={photo}></Kiran>
  </React.StrictMode>
);

 * 
*/
