package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
//@Scope("prototype")
public class Customer {

	private String name;
	private int age;
	@Autowired// specifies the type of object required by the reference variable works on the classname as a type.
	private Address address;
	
	public Customer()
	{
		System.out.println("Hii Bean!!");
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	void display()
	{
		System.out.println("Dependency Injection Implemented Successfully!!");
		address.show();
	}
}
