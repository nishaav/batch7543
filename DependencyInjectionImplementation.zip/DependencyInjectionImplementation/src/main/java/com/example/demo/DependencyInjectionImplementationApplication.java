package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DependencyInjectionImplementationApplication {

	public static void main(String[] args) 
	{
		ConfigurableApplicationContext ctx=
				SpringApplication.run(DependencyInjectionImplementationApplication.class, args);
		//to configure the bean container for the application.
		Customer customer=ctx.getBean(Customer.class);
		customer.display();
		Customer customer1=ctx.getBean(Customer.class);
		customer1.display();
	}
}