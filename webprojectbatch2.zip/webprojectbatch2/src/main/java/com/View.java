package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entities.User;

/**
 * Servlet implementation class View
 */
public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public View() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			doProcess(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request,response);
		
		
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String name=request.getParameter("uname");
		int age=Integer.parseInt(request.getParameter("uage"));
		User user=new User();
		user.setUserName(name);
		user.setUserAge(age);
	
			String result=insertData(user);
		
		//Float.parseFloat
		//Double.parseDouble
		if(result.equalsIgnoreCase("success"))
		{
			out.println("<!doctype html>"
				+ "<html>"
				+ "<head></head>"
				+ "<body>"
				+ "Welcome "+name+"<br>"
				+ "Your age is "+age+"<br>"
				+ "</body>"
				+ "</html>");
		
		}
		else
		{
			out.println("<!doctype html>"
					+ "<html>"
					+ "<head></head>"
					+ "<body>"
					+ "Unable to insert data in database"
					+ "</body>"
					+ "</html>");	
		}
		//update
		
		User u=new User();
		u.setUserId(1);
		u.setUserName("Preeti");
		u.setUserAge(28);
		String status=updateRecord(u);
		
	}

	String insertData(User user)
	{
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			et.begin();
			em.persist(user);//insert query
			et.commit();
			em.close();
			return "success";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "failure";
	}
	
	String updateRecord(User user)
	{//update user_Details set name="Preeti", age=28 where id=1;
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			User u=em.find(User.class, user.getUserId());//where clause
			et.begin();
			u.setUserName(user.getUserName());//update user_details set name='Preeti',
			u.setUserAge(user.getUserAge());//age=28
			et.commit();
			em.close();
			return "updated";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "failure";
	}
	
	String deleteRecord(int id)
	{
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			User u=em.find(User.class, id);//where clause
			//find method can search the data on the basis of primary key only
			et.begin();
			em.remove(u);//delete from user where id=id;
			et.commit();
			em.close();
			return "updated";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "failure";
	}
User getData(int id)
{
	User user=new User();
	try
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
		EntityManager em=emf.createEntityManager();
		user=em.find(User.class, id);//where clause
		em.close();

	}catch(Exception e)
	{
		
	}
	return user;
}
//fetching on the basis of Name
public User findByName(String name)
{
		User user=new User();
		try
		{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
		EntityManager em=emf.createEntityManager();	
		user=(User)em.createQuery("from entities.User where userName='"+name+"'").getSingleResult();
		}
catch(Exception e)
{
	e.printStackTrace();
}		
	return user;
}

public List<User> getAllRecords(String name)
{
	List<User> userList=new ArrayList<User>();
	try
	{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("db1");
		EntityManager em=emf.createEntityManager();	
userList=(List<User>)em.createQuery("from entities.User where userName='"+name+"'").getResultList();
em.close();				
	}
	catch(Exception e)
	{
		e.printStackTrace();	
	}
	return userList;
}



	
}	

