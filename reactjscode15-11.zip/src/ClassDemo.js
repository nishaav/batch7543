//class component
import React from 'react';
//dynamic behaviour 
class Dummy extends React.Component
{
    //Mounting Phase : putting the components on DOM after creation.
    //constructor 1 : constructor is the first method to be called before anything else.
    //it is used to provide the default value to the state and props.(initialisation)
    //getDerivedStateFromProps() 2//
    //render() 3
    //componentDidMount() 4
    render()//default method to be called automatically whenever a class component is requested.
    {
        return(
        <div>
        <h1>{this.props.name}</h1> 
        <h1>Hii Working with a class component</h1>
        <h2>Hii Working with a class component</h2>
        <h3>Hii Working with a class component</h3>
        </div>
        );
    }
    
    //Updating Phase : when a component is updated.
    // change in props and state
    //1)getDerivedStateFromProps()
    //2)shouldComponentUpdate()
    //3)render()
    //4)getSnapshotBeforeUpdate()
    //5)componentDidUpdate()
    //DOM tree: component tree
    //Unmounting: when component is removed from the DOM.
    //componentWillUnmount(): when the component is about to be removed.

}
export default Dummy;