import React from 'react';
class About extends React.Component
{
    render()
    {
        return (
<div>
    <h1> About Us</h1>
    <h6> This page will have the content related to the project topic</h6>
</div>

        );
    }
}

export default About;