import React from 'react';

class Api extends React.Component
{
    constructor(props)
    {
      super(props);
      this.state={
        values:[],
        isLoading:false
      };  
    }

    componentDidMount()
    {
        fetch('/springData/learners/13', {
  method: 'DELETE',
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  }
//   body: JSON.stringify({
//     "learnerName": 'Jatin',
//     "learnerContact": '87546329',
//   })
}).then((response)=>response.json())
.then((js)=>{
   // this.setState({
        //             values:js,
        //             isLoading:true
        //         })
  alert('Data deleted successfully');
        console.log(js);
})
    }

//POST API CALL
//     componentDidMount()
//     {
//         fetch('/springData/learners', {
//   method: 'POST',
//   headers: {
//     'Accept': 'application/json',
//     'Content-Type': 'application/json',
//   },
//   body: JSON.stringify({
//     "learnerName": 'Jatin',
//     "learnerContact": '87546329',
//   })
// }).then((response)=>response.json())
// .then((js)=>{
//    // this.setState({
//         //             values:js,
//         //             isLoading:true
//         //         })
// alert('Congrats! You have registered successfully');
//   console.log(js);
// })
//     }
//GET API CALL
    // componentDidMount()
    // {
    //     fetch("/springData/learners")
    //     .then((response)=>response.json())
    //     .then((js)=>{
    //         this.setState({
    //             values:js,
    //             isLoading:true
    //         })
    //     })
    // }
    render()
    {
        
            if(this.state.isLoading)
            return(
                <div>
                    <h1>API RESPONSE</h1>
                    {this.state.values.map((user)=>(
                        <p>&nbsp;&nbsp;&nbsp;&nbsp;{user.learnerId}  {user.learnerName} {user.learnerContact}</p>
                    ))}    
                </div>
            );
            else
            return(
                <p>Loading your data..Please wait!!</p>
            );

    }

}

export default Api;