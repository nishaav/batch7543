import React, { useState } from "react";

function FormEx() {
    
  const [values, setValues] = useState({ email: "", password: "" });
//useState : used to initialize the properties with default values
  const handleChange = event => {
    const { name, value } = event.target;
    setValues({ ...values, [name]: value });
  };

  const handleSubmit = event => {
    event.preventDefault();//removing the default functionality of submit button\
//action
    alert(JSON.stringify(values, null, 2));
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <label>
        Email:
        <input
          type="email"
          name="email"
          value={values.email}
          onChange={handleChange}
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          name="password"
          value={values.password}
          onChange={handleChange}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
}
export default FormEx;