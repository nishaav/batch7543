import logo from './logo.svg';
import './App.css';
import React from 'react';
//functional component
//
/*
Components :
Functional Component
Class Component
*/

//JSX
// function App() {
//   return (
//     <section className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </section>
//   );
// }

//class component

class Dummy extends React.Component
{
  render()
  {
    return(
<div>
      <h1>Hello Learners</h1>
      <p>We are working on react JS application</p>
</div>
    );
  }
}





//npx create-react-app project_topic

// function Mine()
// {
//   return (
//     <div>
//         <h1>Hello World!!</h1>
//         <p className='App'>My Component is {2*2} times better than yours</p>
//     </div>

//   );
// }

function MineUp(props)
{
  return (
    <div>
        <h1>Hello {props.name}!!</h1>
        <p className='App'>My Component is {2*2} times better than yours</p>
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Project</li>
          <li>Contact Us</li>
        </ul>
        <img src={props.path} alt="extension not supported"></img>

    </div>

  );
}

// function Batch()
// {
//   return(
// <div>
//   <h1>Hello Learners</h1>
//   <p>We are working on react js</p>
// </div>
//   );
// }

export default MineUp;
