//routes : for navigation from one page of the site to another page of the site.

//Route: npm i -D react-router-dom
//npm i -D react-router-dom@latest
//installing reat router dom

import React from 'react';
class Home extends React.Component
{
    render()
    {
        return (
<div>
    <h1> Home</h1>
    <h6> Home page of the site</h6>
</div>

        );
    }
}

export default Home;