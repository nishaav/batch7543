import React from 'react';
class Contact extends React.Component
{
    render()
    {
        return (
<div>
    <h1> Contact Us</h1>
    <h6> This page will have the information related to contact us</h6>
</div>

        );
    }
}

export default Contact;