import React from 'react';

class UpComp extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={color:"red"};
    }
    // static getDerivedStateFromProps(props,state)
    // {
    //     return {color:props.color};
    // }
    //user defined method
    shouldComponentUpdate()
    {
        return true;
    }
    
    changeValue=()=>{
        this.setState({color:"blue"});
    }
    
// webpack : creating a standard react project
// babel : compiler
    render()
    {
        return(
        <div>
        <h1>The Value is {this.state.color}</h1>
        <button type="button" onClick={this.changeValue}>CLICK ME</button>
        </div>
        );
    }

}
export default UpComp;