package com;

import javax.persistence.*;

import com.entities.Address;
import com.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       try
       {
    	   EntityManagerFactory emf=Persistence.createEntityManagerFactory("dbInfo");
    	   EntityManager em=emf.createEntityManager();
    	   EntityTransaction et=em.getTransaction();
    	   et.begin();
    	   
    	   
    	   Student student=new Student();
    	   student.setStudentEmail("anamika@gmail.com");
    	   student.setStudentName("Anamika");
    	   student.setStudentAge(23);
    	   
    	   Address address=new Address();
    	   address.setAddressHouseNo("C-40");
    	   address.setAddressPinCode(110058);
    	   address.setAddressCity("New Delhi");
    	   
    	   student.setAddress(address);
    	   address.setStudent(student);
    	   
    	   em.persist(student);
    	   
    	   et.commit();
    	   em.close();
       }
       catch(Exception e)
       {
    	   e.printStackTrace();
       }
    }
}
