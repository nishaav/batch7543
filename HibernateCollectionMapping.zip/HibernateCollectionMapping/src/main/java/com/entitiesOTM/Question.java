package com.entitiesOTM;

import java.util.List;

import javax.persistence.*;

@Entity
@Table
public class Question {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int QuestionId;
	@Column
	private String QuestionStatement;
	@Column
	private int QuestionMarks;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="qId")
	@OrderColumn(name="type")//allocate index sequence
	List<Answer> answers;
	
	public List<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	public int getQuestionId() {
		return QuestionId;
	}
	public void setQuestionId(int questionId) {
		QuestionId = questionId;
	}
	public String getQuestionStatement() {
		return QuestionStatement;
	}
	public void setQuestionStatement(String questionStatement) {
		QuestionStatement = questionStatement;
	}
	public int getQuestionMarks() {
		return QuestionMarks;
	}
	public void setQuestionMarks(int questionMarks) {
		QuestionMarks = questionMarks;
	}
	
	
	
	
}
