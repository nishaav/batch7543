package com.entitiesOTM;

import javax.persistence.*;

@Entity
@Table
public class Answer {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int AnswerId;
	@Column
	private String AnswerStatement;
	public int getAnswerId() {
		return AnswerId;
	}
	public void setAnswerId(int answerId) {
		AnswerId = answerId;
	}
	public String getAnswerStatement() {
		return AnswerStatement;
	}
	public void setAnswerStatement(String answerStatement) {
		AnswerStatement = answerStatement;
	}
	
	
	
	
}
