package com;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.*;

import com.entitiesOTM.*;

public class AppOTM {

	public static void main(String[] args) {
		try
	       {
	    	   EntityManagerFactory emf=Persistence.createEntityManagerFactory("dbInfo");
	    	   EntityManager em=emf.createEntityManager();
	    	   EntityTransaction et=em.getTransaction();
	    	   et.begin();
	    	   
	    	   Answer answer1=new Answer();
	    	   answer1.setAnswerStatement("Java is a platform independent language");
	    	  
	    	   Answer answer2=new Answer();
	    	   answer2.setAnswerStatement("Java is an object oriented programming language");

	    	   List<Answer> answerList=new ArrayList<Answer>();
	    	   answerList.add(answer1);
	    	   answerList.add(answer2);
	    	   Question question=new Question();
	    	   question.setQuestionStatement("Define Java");
	    	   question.setQuestionMarks(2);
	    	   question.setAnswers(answerList);
	    	   
	    	   em.persist(question);
	    	   
	    	   et.commit();
	    	   em.close();
	       }
	       catch(Exception e)
	       {
	    	   e.printStackTrace();
	       }


	}

}
