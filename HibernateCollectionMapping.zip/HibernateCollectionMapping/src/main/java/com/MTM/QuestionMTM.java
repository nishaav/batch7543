package com.MTM;

import java.util.List;

import javax.persistence.*;



@Entity
@Table
public class QuestionMTM {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int QuestionMTMId;
	@Column
	private String QuestionMTMStatement;
	@Column
	private int QuestionMTMMarks;
	
	@ManyToMany(targetEntity=AnswerMTM.class,cascade=CascadeType.ALL)
	@JoinTable(name="QuesAns",
	joinColumns= {@JoinColumn(name="qId")},
	inverseJoinColumns= {@JoinColumn(name="ansId")}
			)
	List<AnswerMTM> answersMTM;
	
	public List<AnswerMTM> getAnswersMTM() {
		return answersMTM;
	}
	public void setAnswersMTM(List<AnswerMTM> answersMTM) {
		this.answersMTM = answersMTM;
	}
	public int getQuestionMTMId() {
		return QuestionMTMId;
	}
	public void setQuestionMTMId(int questionMTMId) {
		QuestionMTMId = questionMTMId;
	}
	public String getQuestionMTMStatement() {
		return QuestionMTMStatement;
	}
	public void setQuestionMTMStatement(String questionMTMStatement) {
		QuestionMTMStatement = questionMTMStatement;
	}
	public int getQuestionMTMMarks() {
		return QuestionMTMMarks;
	}
	public void setQuestionMTMMarks(int questionMTMMarks) {
		QuestionMTMMarks = questionMTMMarks;
	}
	
}
