package com.MTM;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class AnswerMTM {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int AnswerMTMId;
	@Column
	private String AnswerMTMStatement;
	public int getAnswerMTMId() {
		return AnswerMTMId;
	}
	public void setAnswerMTMId(int answerMTMId) {
		AnswerMTMId = answerMTMId;
	}
	public String getAnswerMTMStatement() {
		return AnswerMTMStatement;
	}
	public void setAnswerMTMStatement(String answerMTMStatement) {
		AnswerMTMStatement = answerMTMStatement;
	}
	
	
	
}
