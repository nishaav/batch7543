package com;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.MTM.AnswerMTM;
import com.MTM.QuestionMTM;

public class AppMTM {

	public static void main(String[] args) {
		try
	       {
	    	   EntityManagerFactory emf=Persistence.createEntityManagerFactory("dbInfo");
	    	   EntityManager em=emf.createEntityManager();
	    	   EntityTransaction et=em.getTransaction();
	    	   et.begin();
	    	   
	    	   AnswerMTM answer1=new AnswerMTM();
	    	   answer1.setAnswerMTMStatement("Java is a platform independent language");
	    	  
	    	   AnswerMTM answer2=new AnswerMTM();
	    	   answer2.setAnswerMTMStatement("Java is an object oriented programming language");

	    	   List<AnswerMTM> answerList=new ArrayList<AnswerMTM>();
	    	   answerList.add(answer1);
	    	   answerList.add(answer2);
	    	   QuestionMTM question=new QuestionMTM();
	    	   question.setQuestionMTMStatement("Define Java");
	    	   question.setQuestionMTMMarks(2);
	    	   question.setAnswersMTM(answerList);
	    	   
	    	   QuestionMTM question1=new QuestionMTM();
	    	   question1.setQuestionMTMStatement("What Is Java");
	    	   question1.setQuestionMTMMarks(2);
	    	   question1.setAnswersMTM(answerList);
	    	   
	    	   
	    	   em.persist(question);
	    	   em.persist(question1);
	    	   
	    	   et.commit();
	    	   em.close();
	       }
	       catch(Exception e)
	       {
	    	   e.printStackTrace();
	       }
	}

}
