package com.entities;

import javax.persistence.*;

@Entity
@Table
public class Address 
{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int AddressId;
	@Column
	private String AddressHouseNo;
	@Column
	private int AddressPinCode;
	@Column
	private String AddressCity;
	
	@OneToOne(targetEntity=Student.class)
	private Student student;
	
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public int getAddressId() {
		return AddressId;
	}
	public void setAddressId(int addressId) {
		AddressId = addressId;
	}
	public String getAddressHouseNo() {
		return AddressHouseNo;
	}
	public void setAddressHouseNo(String addressHouseNo) {
		AddressHouseNo = addressHouseNo;
	}
	public int getAddressPinCode() {
		return AddressPinCode;
	}
	public void setAddressPinCode(int addressPinCode) {
		AddressPinCode = addressPinCode;
	}
	public String getAddressCity() {
		return AddressCity;
	}
	public void setAddressCity(String addressCity) {
		AddressCity = addressCity;
	}
	
	
	
}
