package com.example.demo;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class DemoAppApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(DemoAppApplication.class, args);
//	}
//}


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication//specifies the application type
public class DemoAppApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(DemoAppApplication.class, args);//initialising spring bean container
		Customer c = context.getBean(Customer.class);//fetching the object of Customer.class type
		c.display();//calling the display method of customer class
	}

}
